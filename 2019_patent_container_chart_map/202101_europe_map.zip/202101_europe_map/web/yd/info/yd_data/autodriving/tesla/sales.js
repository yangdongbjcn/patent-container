
var jsondb_autodriving_tesla_sales = {};

jsondb_autodriving_tesla_sales.keys = ["production","sales"];

jsondb_autodriving_tesla_sales.index = ["2013","2014","2015","2016","2017","2018","2019"];

jsondb_autodriving_tesla_sales.rows = [["22442","34851"],["31655","35000"],["50658","51095"],["76297","83922"],["103181","101027"],["245162","254530"],["367200","365194"]];

// jsondb_autodriving_tesla_sales.mat = [];
// jsondb_autodriving_tesla_sales.mat.concat([["year","sales","production"],["2013","22442","34851"],["2014","31655","35000"],["2015","50658","51095"],["2016","76297","83922"],["2017","103181","101027"],["2018","245162","254530"],["2019","367200","365194"]]);
