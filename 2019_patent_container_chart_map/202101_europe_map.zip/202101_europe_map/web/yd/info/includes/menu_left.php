<script src="<?php echo $g_yd__includes ?>/menu_left.js"></script>

<div class='row-fluid'><!-- menu_left+content+menu_right row -->

<div class='col-sm-2 well'><!-- left menu starts -->
	<ul class='nav nav-pills nav-stacked'>		
		<li class='nav-header hidden-tablet'>目录</li>
	</ul>
</div><!-- left menu ends -->

<div class='col-sm-8'><!-- content starts -->