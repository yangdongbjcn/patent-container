<script src="<?php echo $g_yd__includes ?>menu_top.js"></script>

<div class='container-fluid'><!-- 全局container -->

<div class='row-fluid'><!-- menu_top row -->

	<!-- top menu starts -->
	<div class='navbar navbar-default' role='navigation'>			
		<ul class='nav navbar-nav'>
			<li><a>智力容器</a></li>
			<li class='drop-down' style="display: none">
				<a class='dropdown-toggle' data-toggle='dropdown'>
					<span class='icon-user'></span>
					About
					<span class='caret'></span>
				</a>
				<ul class='dropdown-menu'>
					<li><a href='<?php echo $g_yd__yangdong ?>'>YANGDONG</a></li>
				</ul>
			</li>
			<li><a>京ICP备10217364号</a></li>
		</ul>
		
	</div>
	<!-- top menu ends -->
</div><!-- menu_top row -->