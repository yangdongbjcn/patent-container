<script type='text/javascript' src='<?php echo $g_yd__resources ?>bootstrap/js/bootstrap.js'></script>

<!--[if lte IE 8]>
<script src='<?php echo $g_yd__resources ?>bootstrap_ie8/respond.min.js'></script>
<script src='<?php echo $g_yd__resources ?>bootstrap_ie8/html5shiv.min.js'></script>
<![endif]-->

<!--[if IE]>
<script src="<?php echo $g_yd__resources ?>base64-polyfill.js"></script>
<![endif]-->

<script src='<?php echo $g_yd__includes ?>/end.js'></script>

</body>

</html>