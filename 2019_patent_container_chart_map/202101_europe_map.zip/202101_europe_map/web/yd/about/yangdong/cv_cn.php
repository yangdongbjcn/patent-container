<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="cv_cn/content.css">
	<script type="text/javascript" src="cv_cn/content.js"></script>
<?php
	include("cv_cn/content.php");
?>
<?php 
	include('after.php');
?>