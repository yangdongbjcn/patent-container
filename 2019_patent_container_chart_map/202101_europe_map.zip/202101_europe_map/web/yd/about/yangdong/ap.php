﻿<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="ap/content.css">
	<script type="text/javascript" src="ap/content.js"></script>
<?php
	include("ap/content.php");
?>
<?php 
	include('after.php');
?>