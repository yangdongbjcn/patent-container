<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="cv_en/content.css">
	<script type="text/javascript" src="cv_en/content.js"></script>
<?php
	include("cv_en/content.php");
?>
<?php 
	include('after.php');
?>