<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="container_dev/content.css">
	<script type="text/javascript" src="container_dev/content.js"></script>
<?php
	include("container_dev/content.php");
?>
<?php 
	include('after.php');
?>
