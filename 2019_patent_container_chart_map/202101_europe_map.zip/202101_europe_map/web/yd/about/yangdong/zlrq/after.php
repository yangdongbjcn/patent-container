<?php
	include('../../../info/includes/menu_right.php');
	include('../../../info/includes/footer.php'); 
	include('../../../info/includes/end.php');
?>