<!-- row-fluid -->
<div class='row-fluid'>

<!-- left menu starts -->
<div class='col-sm-2 well'>
	<ul class='nav nav-pills nav-stacked'>
		<li><a href='container_wiki.php'>容器百科</a></li>
		<li><a href='container_idea.php'>容器思想</a></li>
		<li><a href='container_data.php'>容器数据</a></li>
		<li><a href='container_example.php'>容器举例</a></li>
		<li><a href='container_dev.php'>容器开发</a></li>
	</ul>
</div><!--span 2-->
<!-- left menu ends -->

<!-- span 10 starts -->
<div class='col-sm-8'>