<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="container_data/content.css">
	<script type="text/javascript" src="container_data/content.js"></script>
<?php
	include("container_data/content.php");
?>
<?php 
	include('after.php');
?>