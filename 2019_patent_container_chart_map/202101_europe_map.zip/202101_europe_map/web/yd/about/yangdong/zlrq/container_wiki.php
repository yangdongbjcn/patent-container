<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="container_wiki/content.css">
	<script type="text/javascript" src="container_wiki/content.js"></script>
<?php
	include("container_wiki/content.php");
?>
<?php 
	include('after.php');
?>