<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="container_idea/content.css">
	<script type="text/javascript" src="container_idea/content.js"></script>
<?php
	include("container_idea/content.php");
?>
<?php 
	include('after.php');
?>