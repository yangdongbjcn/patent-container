<div class="row">
	<div class='col-sm-12'>
		<h2>专利容器</h2>
		<h3>容器编程</h3>
		<p>1）安装anaconda2，https://mirrors.tuna.tsinghua.edu.cn/help/anaconda/</p>
		<p>2）打开anaconda的命令行，安装依赖库。</p>
		<p>pip install jieba</p>
		<p>pip install gensim</p>
		<p>conda install xlutils</p>
		<p>3）安装pycharm，选择免费的社区版，https://www.jetbrains.com/pycharm </p>
		<p>4）下载本库的代码，使用pycharm运行yd_container_test.py</p>
	</div>
</div>