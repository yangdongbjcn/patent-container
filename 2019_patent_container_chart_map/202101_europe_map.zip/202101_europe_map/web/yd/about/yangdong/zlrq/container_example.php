<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="container_example/content.css">
	<script type="text/javascript" src="container_example/content.js"></script>
<?php
	include("container_example/content.php");
?>
<?php 
	include('after.php');
?>