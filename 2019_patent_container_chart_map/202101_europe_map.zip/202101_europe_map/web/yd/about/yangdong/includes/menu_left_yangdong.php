<!-- row-fluid -->
<div class='row-fluid'>

<!-- left menu starts -->
<div class='col-sm-2 well'>
	<ul class='nav nav-pills nav-stacked'>
		<li class='nav-header hidden-tablet'>简历</li>
		<li><a href='cv_cn.php'>简历</a></li>
		<li><a href='cv_en.php'>CV</a></li>
		<li class='nav-header hidden-tablet'>科研</li>
		<li><a href='ap.php'>AP聚类</a></li>
		<li><a href='zlrq/'>专利容器</a></li>
		<li class='nav-header hidden-tablet'>GitHub</li>
		<li><a href='https://github.com/yangdongbjcn/patent-container'>patent-container</a></li>
		<li><a href='https://github.com/yangdongbjcn/webpage-includer'>webpage-includer</a></li>
		<li><a href='https://github.com/yangdongbjcn/webpage-includer-codeigniter'>webpage-includer-codeigniter</a></li>
		<li><a href='https://github.com/yangdongbjcn/PaReLab'>PaReLab</a></li>
	</ul>
</div><!--span 2-->
<!-- left menu ends -->

<!-- span 10 starts -->
<div class='col-sm-8'>