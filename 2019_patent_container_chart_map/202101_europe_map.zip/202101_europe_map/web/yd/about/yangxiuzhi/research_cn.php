<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="research_cn/content.css">
	<script type="text/javascript" src="research_cn/content.js"></script>
<?php
	include("research_cn/content.php");
?>
<?php 
	include('after.php');
?>