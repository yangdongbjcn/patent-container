<div class="row">
	<div class='col-sm-12'>
		<h2>杨秀治老师主要的科学研究成果</h2>
		<form class='form-horizontal'>
			<fieldset>
				<div>
					<table class='table table-bordered'>
						<thead>			
							<tr>
								<th width="30%">名称</td>
								<th width="30%">杂志或出版社</td>
								<th width="10%">期别</td>
								<th width="10%">时间</td>
								<th width="20%">本人承担部分</td>
							</tr>
						</thead> 
						<tbody>	
							<tr>
								<th width="30%">名称西方国家的返校制度及其对教育公平的影响</td>
								<th width="30%">教育科学</td>
								<th width="10%">2005.6</td>
								<th width="10%">2005.12</td>
								<th width="20%">第一作者</td>
							</tr>
							<tr>
								<th width="30%">新时期培训者的素质与发展</td>
								<th width="30%">中小学老师培训</td>
								<th width="10%">2006.3</td>
								<th width="10%">2006.6</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">农村义务教育老师大规模有效培训的政策与模式研究--以北京市“绿色耕耘行动”为个案</td>
								<th width="30%">江苏教育研究</td>
								<th width="10%"></td>
								<th width="10%">2008.8</td>
								<th width="20%">第二作者</td>
							</tr>
							<tr>
								<th width="30%">超越分科与不分科之争—高中分科教学的国际比较研究及其启示</td>
								<th width="30%">比较教育研究</td>
								<th width="10%"></td>
								<th width="10%">2009.10</td>
								<th width="20%">第一作者</td>
							</tr>
							<tr>
								<th width="30%">打造班主任专业发展带头人——北京市优秀班主任工作室的经验与特色</td>
								<th width="30%">中国德育</td>
								<th width="10%">2010.6</td>
								<th width="10%">2010.6</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">打造专家型优秀班主任群体——记北京市优秀班主任室</td>
								<th width="30%">北京教育</td>
								<th width="10%">2010.6</td>
								<th width="10%">2010.6</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">当前中小学校长培训者角色分析</td>
								<th width="30%">北京教育学院学报</td>
								<th width="10%">2010.5</td>
								<th width="10%">2010.10</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">印度创建世界一流大学政策研究</td>
								<th width="30%">比较教育研究</td>
								<th width="10%"></td>
								<th width="10%">2016.6</td>
								<th width="20%">第一作者</td>
							</tr>
							<tr>
								<th width="30%">从《不让一个孩子掉队法案》到《每个学生都成功法案》:美国中小学教育问责体系的演变</td>
								<th width="30%">外国教育研究</td>
								<th width="10%">2017.5</td>
								<th width="10%">2017.5</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">西方大学建筑文化及教育意蕴</td>
								<th width="30%">全球教育展望</td>
								<th width="10%">2017.5</td>
								<th width="10%">2017.5</td>
								<th width="20%">独立</td>
							</tr>
							<tr>
								<th width="30%">教师生涯阶段研究：标准、论域与方法</td>
								<th width="30%">中国教育学刊</td>
								<th width="10%">2017.7</td>
								<th width="10%">2017.7</td>
								<th width="20%">独立</td>
							</tr>
						</tbody>
					</table>
				</div>
			</fieldset>
		</form>
	</div>
</div>