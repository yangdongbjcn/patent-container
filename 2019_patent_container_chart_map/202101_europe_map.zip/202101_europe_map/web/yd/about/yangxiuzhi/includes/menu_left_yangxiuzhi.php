<!-- row-fluid -->
<div class='row-fluid'>

<!-- left menu starts -->
<div class='col-sm-2 well'>
	<ul class='nav nav-pills nav-stacked'>
		<li class='nav-header hidden-tablet'>简历</li>
		<li><a href='cv_cn.php'>简历</a></li>
		<li class='nav-header hidden-tablet'>科研</li>
		<li><a href='research_cn.php'>成果</a></li>
	</ul>
</div><!--span 2-->
<!-- left menu ends -->

<!-- span 10 starts -->
<div class='col-sm-8'>