<?php
	include('before.php');
?>
	<link href="<?php echo $g_bjzx_dj ?>daily/content.css" rel="stylesheet">
	<script type="text/javascript" src="<?php echo $g_bjzx_dj ?>daily/content.js"></script>
<?php
	include("daily/content.php");
?>
<?php
	include('after.php');
?>
