<?php
	include('../../yd/basepath.php');
	include('../../yd/info/includes/begin.php');
	include('includes/before_config.php');
	include('includes/menu_top.php');
	include('includes/menu_left_admin.php');
?>