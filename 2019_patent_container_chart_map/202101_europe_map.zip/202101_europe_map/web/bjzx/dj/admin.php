<?php
	include('before_admin.php');
?>
	<link href='<?php echo $g_bjzx_dj ?>admin/content.css' rel='stylesheet'>
	<script type='text/javascript' src='<?php echo $g_bjzx_dj ?>admin/content.js'></script>
<?php
	include('admin/content.php');
?>
<?php
	include('after.php');
?>