<div>
	<table class='table table-condensed' id='dailyadmin_view_urls'>
		<thead>
			<tr>
				<th>分类</th>
				<th>标题</th>
				<th>URL</th>
				<th>开始日期</th>
				<th>结束日期</th>
				<th>提交人</th>
				<th>备注</th>
				<th>操作</th>
			</tr>
		</thead> 
	    <tbody>	    
		    
	    </tbody>
	</table>
</div>