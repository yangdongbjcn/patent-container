<?php
	include('../../yd/info/includes/footer.php'); 
	include('../../yd/info/includes/end.php');
?>