g_var.pre_daily_types = new Array();
// g_var.pre_daily_types['yzyh100'] = '应知应会100题';
// g_var.pre_daily_types['yzyh50'] = '应知应会50条';
// g_var.pre_daily_types['yqzq'] = '疫情专区';
g_var.pre_daily_types['wen30'] = '严格党内组织生活30问';
$('body').css("background-color","#FF7F24");