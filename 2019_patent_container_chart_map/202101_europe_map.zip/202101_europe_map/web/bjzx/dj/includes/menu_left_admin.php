<script src="<?php echo $g_bjzx_dj ?>includes/menu_left_admin.js"></script>

<!-- row-fluid -->
<div class='row-fluid'>

<!-- left menu starts -->
<div class='col-sm-2 span2 well'>
	<ul class='nav nav-pills nav-stacked'>
		<li class='nav-header hidden-tablet'>每日学习</li>
		<li id='active_left_daily_newest'><a id='left_daily_newest'>最新</a></li>
	</ul>
	<ul class='nav nav-pills nav-stacked'>
		<li class='nav-header hidden-tablet'>管理员操作</li>
		<li id='active_left_dailyadmin_view_urls'><a id='left_daily_view_urls'>浏览全部内容</a></li>
		<li id='active_left_dailyadmin_add_url'><a id='left_daily_add_url'>增加内容</a></li>
	</ul>
</div><!--span 2-->
<!-- left menu ends -->

<!-- span 10 starts -->
<div class='col-sm-10 span10'>