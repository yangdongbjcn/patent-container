<script src="<?php echo $g_bjzx_dj ?>includes/menu_left.js"></script>

<!-- row-fluid -->
<div class='row-fluid'>

<!-- left menu starts -->
<div class='col-sm-2 span2 well'>
	<ul class='nav nav-pills nav-stacked'>

		<li class='nav-header hidden-tablet'>每日学习</li>
		<li id='active_left_daily_newest'><a id='left_daily_newest'>最新</a></li>
		<li id='active_left_daily_newest'><a id='left_daily_newest'>严格党内组织生活30问</a></li>
		<!-- <li id='active_left_daily_kjyq'><a id='left_daily_kjyq'> 疫情专区</a></li> -->
		<!-- <li id='active_left_daily_yzyh100'><a id='left_daily_yzyh100'> 应知应会100题</a></li> -->
		<!-- <li id='active_left_daily_yzyh50'><a id='left_daily_yzyh50'> 应知应会50条</a></li> -->
	</ul>
</div><!--span 2-->
<!-- left menu ends -->

<!-- span 10 starts -->
<div class='col-sm-10 span10'>