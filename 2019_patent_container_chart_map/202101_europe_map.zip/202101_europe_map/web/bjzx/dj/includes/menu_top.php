<script src="<?php echo $g_bjzx_dj ?>includes/menu_top.js"></script>

<!-- container-fluid -->
<div class='container-fluid'>
<!-- row-fluid -->
<div class='row-fluid'>

	<!-- top menu starts -->
	<div class='navbar navbar-default' role='navigation'>
			
		<ul class='nav navbar-nav'>
			<li><a href='http://bjzx.sipo'>北京中心</a></li>
			<li><a href='http://bjzx.sipo/dtgqf/index.jhtml'>党建工作</a></li>
			<li><a href='http://10.77.59.161/web/bjzx/dj'>每日学习</a></li>
		</ul>
		
	</div>
	<!-- top menu ends -->
</div>
<!-- row-fluid -->