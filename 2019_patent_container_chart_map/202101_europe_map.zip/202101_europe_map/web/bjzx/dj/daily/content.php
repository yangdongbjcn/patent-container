<div id='daily_div'>
</div>
