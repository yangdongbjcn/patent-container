<?php
	include('before_admin.php');
?>
	<link href='<?php echo $g_bjzx_dj ?>dailyadmin_modify_url/content.css' rel='stylesheet'>
	<script type='text/javascript' src='<?php echo $g_bjzx_dj ?>dailyadmin_modify_url/content.js'></script>
<?php
	include('dailyadmin_modify_url/content.php');
?>
<?php
	include('after.php');
?>