<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='utf-8'>

	<meta http-equiv='X-UA-Compatible' content='IE=9' />

	<meta name='viewport' content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<title></title>

	<link rel='stylesheet' href='<?php echo $g_yd__resources ?>bootstrap/css/bootstrap.css'>
	
  <link rel='shortcut icon' href='<?php echo $g_yd__resources ?>img/wi64.ico'>

  <script type='text/javascript' src='<?php echo $g_yd__resources ?>jquery/jquery.js'></script>

</head>

<body>

<script type='text/javascript' src='<?php echo $g_yd ?>basepath.js'></script>

<script src='<?php echo $g_yd__resources ?>echarts/echarts.js'></script>

<link href='<?php echo $g_yd__container ?>yd_css/yd_layout_margin.css' rel='stylesheet'>


<link href='<?php echo $g_yd__resources ?>datatables/css/jquery.dataTables.css' rel='stylesheet'>
<!-- <link href='<?php echo $g_yd__resources ?>datatables/css/jquery.dataTables.bootstrap.css' rel='stylesheet'> -->
<script src='<?php echo $g_yd__resources ?>datatables/js/jquery.dataTables.js'></script>

<script src="<?php echo $g_yd__container ?>yd_js/yd_object.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_list.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_dict.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_mat.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_frame.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_cube.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_box.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_tree.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_page.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_text.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_map.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_patent.js"></script>
<script src="<?php echo $g_yd__container ?>yd_js/yd_chart.js"></script>


<link rel='stylesheet' href='<?php echo $g_yd__resources ?>zTree_v3/css/zTreeStyle/zTreeStyle.css'>

<script type='text/javascript' src='<?php echo $g_yd__resources ?>zTree_v3/js/jquery.ztree.core.js'></script>

<script type='text/javascript' src='<?php echo $g_yd__resources ?>/js_datepic/laydate.js'></script>
