<script src="<?php echo $g_yd__includes ?>/menu_right.js"></script>

</div><!-- content ends -->

<div class='col-sm-2'><!-- menu_right starts -->
	
</div><!-- menu_right ends -->

</div><!-- menu_left+content+menu_right row -->