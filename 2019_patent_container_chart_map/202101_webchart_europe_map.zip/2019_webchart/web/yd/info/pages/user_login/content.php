<div class='container-fluid'> <!-- container比container-fluid多一个随视口宽度变化的margin -->
<div class='row-fluid'>

  <div class='col-sm-3'></div>
  <div class='col-sm-6'>

    <div class='well yd_layout_margin_top_s'>
    
      <div class='input-group'>
        <span class='input-group-addon'>User Name</span>
        <input id='u_eng_name' autofocus class='form-control' type='text'/>
      </div>

      <div class='input-group yd_layout_margin_top_s'>
        <span class='input-group-addon'>Password</span>
        <input id='u_psd' class='form-control' type='password'/>
      </div>

      <button id='submit' class='btn yd_layout_margin_top_s yd_layout_width_xs yd_layout_center'>Sign In</button> 
    </div><!--/well-->

    <div class='well'>
      <p>
      Note:
      </p>
      <p>
      1. Please use DXB training accounts.
      </p>
    </div><!--/well-->

  </div>

  <div class='col-sm-3'></div>
</div>
</div>


  

