<?php
	include('before.php');
?>

	<link rel='stylesheet' href='<?php echo $g_yd_info ?>pages/user_login/content.css'>
	<script type='text/javascript' src='<?php echo $g_yd_info ?>pages/user_login/content.js'></script>
	
<?php
	include('user_login/content.php');
?>
<?php
	include('after.php');
?>