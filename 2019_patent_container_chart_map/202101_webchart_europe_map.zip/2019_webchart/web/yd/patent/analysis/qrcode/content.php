<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>将文本转换为二维码：</p>
	      <p>1. IE下文本不要太长。  </p>
	    </div><!--/well-->
	</div>
</div>

<div class='row'>
	<div class='col-sm-6'>
		<p>输入文本</p>
		<textarea id='qrcode_text' class='form-control' rows='27'></textarea>
	</div>
	<div class='col-sm-6'>
		<p>输出二维码</p>
		<div id='qrcode_div'>
		</div>
	</div>
</div> <!-- end row -->

<div class='row'>	
	<a class='btn btn-success yd_layout_margin_top_s yd_layout_width_xs yd_layout_center' id='qrcode_button_ie'>
		IE浏览器
	</a>
	<a class='btn btn-success yd_layout_margin_top_s yd_layout_width_xs yd_layout_center' id='qrcode_button'>
		其他浏览器
	</a>
</div> <!-- end row --> 
