<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="sheet_json2/content.css">
	<script type="text/javascript" src="sheet_json2/content.js"></script>
<?php
	include("sheet_json2/content.php");
?>
<?php 
	include('after.php');
?>