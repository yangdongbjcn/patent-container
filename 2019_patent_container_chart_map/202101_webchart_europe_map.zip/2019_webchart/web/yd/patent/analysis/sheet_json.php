<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="sheet_json/content.css">
	<script type="text/javascript" src="sheet_json/content.js"></script>
<?php
	include("sheet_json/content.php");
?>
<?php 
	include('after.php');
?>