<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>生成JSON2：</p>
	      <p>1, 直接从EXCEL中拷贝；</p>
		  <p>2, 默认第一行是字段名；</p>
		  <p>3, 默认第一列是索引列。</p>
	    </div><!--/well-->
	</div>
</div>

<div class='row'> 
	<div class='col-sm-6'>
		<p>输入文本</p>
		<textarea id='input_text' class='form-control' rows='27'></textarea>
	</div>
	<div class='col-sm-6'>
		<p>输出文本</p>
		<textarea id='result_text' class='form-control' rows='27'></textarea>
	</div>
</div> <!-- end row -->

<div class='row'>	
	<a class='btn btn-success yd_layout_margin_top_s yd_layout_center yd_layout_width_xs' id='submit'>
		转换
	</a>
</div> <!-- end row -->

