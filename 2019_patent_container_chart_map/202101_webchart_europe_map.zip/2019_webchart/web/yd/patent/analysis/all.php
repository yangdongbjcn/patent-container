<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="all/content.css">
	<script type="text/javascript" src="all/content.js"></script>
<?php
	include("all/content.php");
?>
<?php 
	include('after.php');
?>
