<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>根据中文名查找：</p>
	      <p>1. 英文名称一般为一个单词。  </p>
	      <p>2. 中文名称尽量简短。  </p>
	    </div><!--/well-->
	</div>
</div>

<div class='row'>
	<div class='col-sm-4'>
		<p>国别代码</p>
		<textarea id='input_text' class='form-control' rows='10'></textarea>
	</div>
	<div class='col-sm-4'>
		<p>英文名称</p>
		<textarea id='result_text1' class='form-control' rows='10'></textarea>
	</div>
	<div class='col-sm-4'>
		<p>中文名称</p>
		<textarea id='result_text2' class='form-control' rows='10'></textarea>
	</div>
</div> <!-- end row -->

<div class='row'>
	<div class='col-sm-12'>
		<a class='btn btn-success yd_layout_margin_top_s yd_layout_width_xs yd_layout_center' id='submit'>
			确定
		</a>
	</div> 
</div> <!-- end row -->
