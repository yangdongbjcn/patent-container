<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_nation/content.css">
	<script type="text/javascript" src="extract_nation/content.js"></script>
<?php
	include("extract_nation/content.php");
?>
<?php 
	include('after.php');
?>