<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>提取特定年份：</p>
	      <p>1. 输入文本来自于S系统的统计结果。  </p>
	      <p>2. 判断条件：最后是年份。  </p>
	    </div><!--/well-->
	</div>
</div>

<div class='row'> 
	<div class='col-sm-6'>
		<p>输入文本</p>
		<textarea id='input_text' class='form-control' rows='27'></textarea>
	</div>
	<div class='col-sm-6'>
		<p>输出文本</p>
		<textarea id='result_text' class='form-control' rows='27'></textarea>
	</div>
</div> <!-- end row -->

<div class='row'>	
	<div class='col-sm-12'>
		<a class='btn btn-success yd_layout_margin_top_s yd_layout_width_xs yd_layout_center' id='submit'>
			确定
		</a> 
	</div>
</div>
