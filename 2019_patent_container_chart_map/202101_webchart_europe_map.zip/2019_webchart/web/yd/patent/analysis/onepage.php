<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="onepage/content.css">
	<script type="text/javascript" src="onepage/content.js"></script>
<?php
	include("onepage/content.php");
?>
<?php 
	include('after.php');
?>
