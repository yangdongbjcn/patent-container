<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_ipc/content.css">
	<script type="text/javascript" src="extract_ipc/content.js"></script>
<?php
	include("extract_ipc/content.php");
?>
<?php 
	include('after.php');
?>