<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="standard_applicant/content.css">
	<script type="text/javascript" src="standard_applicant/content.js"></script>
<?php
	include("standard_applicant/content.php");
?>
<?php 
	include('after.php');
?>