<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="search_input/content.css">
	<script type="text/javascript" src="search_input/content.js"></script>
<?php
	include("search_input/content.php");
?>
<?php 
	include('after.php');
?>