<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_pn/content.css">
	<script type="text/javascript" src="extract_pn/content.js"></script>
<?php
	include("extract_pn/content.php");
?>
<?php 
	include('after.php');
?>