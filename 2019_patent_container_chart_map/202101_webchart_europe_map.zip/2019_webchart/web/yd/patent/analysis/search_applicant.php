<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="search_applicant/content.css">
	<script type="text/javascript" src="search_applicant/content.js"></script>
<?php
	include("search_applicant/content.php");
?>
<?php 
	include('after.php');
?>
