<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_nation_some/content.css">
	<script type="text/javascript" src="extract_nation_some/content.js"></script>
<?php
	include("extract_nation_some/content.php");
?>
<?php 
	include('after.php');
?>