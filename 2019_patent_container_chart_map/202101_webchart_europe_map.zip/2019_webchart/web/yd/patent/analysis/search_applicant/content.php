<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>申请人扩展并生成检索式：</p>
	      <p>1. 申请人映射表(只保留第一次匹配)。  </p>
	    </div><!--/well-->
	</div>
</div>

<div class='row'>
	<div class='col-sm-4'>
		<p>输入文本</p>
		<textarea id='input_text' class='form-control' rows='27'></textarea>
	</div>	
	<div class='col-sm-4'>
		<p>申请人映射表(只保留第一次匹配)</p>
		<textarea id='map_text' class='form-control' rows='27'></textarea>
	</div>
	<div class='col-sm-4'>
		<p>输出文本</p>
		<textarea id='result_text' class='form-control' rows='27'></textarea>
	</div>
</div> <!-- end row -->

<div class='row'>	
	<div class='col-sm-12'>
		<div class='input-group yd_layout_margin_top_s'>
	    	<span class='input-group-addon'>后缀</span>
	    	<input id='input_postfix' class='form-control'></input>
	    	<span class='input-group-btn'>
	    		<button class="btn btn-warning" type='button' id='submit'>生成检索式</button>
	    	</span>
	    </div>
	</div>
</div>
