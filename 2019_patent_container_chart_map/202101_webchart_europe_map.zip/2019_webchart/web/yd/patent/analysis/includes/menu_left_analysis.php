
<div class='row-fluid'><!-- menu_left+content+menu_right row -->

<div class='col-sm-2 well'><!-- left menu starts -->
	<ul class='nav nav-pills nav-stacked'>
		<li>
			<a href='<?php echo $g_yd__analysis ?>onepage.php'> 专利分析一页通 </a>
		</li>
	</ul>
</div><!-- left menu ends -->

<div class='col-sm-8'><!-- content starts -->