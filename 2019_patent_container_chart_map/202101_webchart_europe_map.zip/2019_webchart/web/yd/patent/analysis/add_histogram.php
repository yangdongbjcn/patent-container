<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="add_histogram/content.css">
	<script type="text/javascript" src="add_histogram/content.js"></script>
<?php
	include("add_histogram/content.php");
?>
<?php 
	include('after.php');
?>