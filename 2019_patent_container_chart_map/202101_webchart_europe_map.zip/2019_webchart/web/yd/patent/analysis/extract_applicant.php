<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_applicant/content.css">
	<script type="text/javascript" src="extract_applicant/content.js"></script>
<?php
	include("extract_applicant/content.php");
?>
<?php 
	include('after.php');
?>