<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="sheet_mat/content.css">
	<script type="text/javascript" src="sheet_mat/content.js"></script>
<?php
	include("sheet_mat/content.php");
?>
<?php 
	include('after.php');
?>