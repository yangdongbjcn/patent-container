<?php 
	include('../../basepath.php');	 
	include('../../info/includes/begin.php');
	include('../../info/includes/before_config.php');
	include('../../info/includes/menu_top.php');
	include('includes/menu_left_analysis.php');
?>