<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="nation_name/content.css">
	<script type="text/javascript" src="nation_name/content.js"></script>
<?php
	include("nation_name/content.php");
?>
<?php 
	include('after.php');
?>