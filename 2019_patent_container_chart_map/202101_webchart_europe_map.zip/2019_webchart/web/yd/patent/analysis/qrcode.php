<?php
	include('before.php');
?>

	<link href='>qrcode/content.css' rel='stylesheet'>

	<script src='<?php echo $g_yd__resources ?>jquery-qrcode/jquery-qrcode.min.js'></script>

	<script src='qrcode/content.js'></script>

<?php
	include('qrcode/content.php');
?> 

<?php
	include('after.php');
?>		
