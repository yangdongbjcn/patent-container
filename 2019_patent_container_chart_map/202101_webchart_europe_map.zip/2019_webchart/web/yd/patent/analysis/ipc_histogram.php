<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="ipc_histogram/content.css">
	<script type="text/javascript" src="ipc_histogram/content.js"></script>
<?php
	include("ipc_histogram/content.php");
?>
<?php 
	include('after.php');
?>