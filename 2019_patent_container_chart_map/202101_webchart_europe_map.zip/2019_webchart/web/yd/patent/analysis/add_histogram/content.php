<div class='row'>
	<div class='col-sm-12'>
		<div class='well'>
	      <p>直方图合并：</p>
	      <p>1. 建议直接从excel中拷贝；数据之间用tab分隔。  </p> 
	      <p>2. 第1列是索引，第1列是数字。  </p>
	      <p>3. 从第1行开始，遇到重复索引会自动累加。  </p> 
	    </div><!--/well-->
	</div>
</div>

<div class='row'>
	<div class='col-sm-6'>
		<p>输入文本</p>
		<textarea id='input_text' class='form-control' rows='27'></textarea>
	</div>
	<div class='col-sm-6'>
		<p>结果文本</p>
		<textarea id='result_text' class='form-control' rows='27'></textarea>
	</div>
</div> <!-- end row -->

<div class='row'>	
	<a class='btn btn-success yd_layout_margin_top_s yd_layout_center yd_layout_width_xs' id='submit'>
		确定
	</a>
</div> <!-- end row -->
