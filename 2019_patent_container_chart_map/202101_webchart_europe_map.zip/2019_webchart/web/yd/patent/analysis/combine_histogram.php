<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="combine_histogram/content.css">
	<script type="text/javascript" src="combine_histogram/content.js"></script>
<?php
	include("combine_histogram/content.php");
?>
<?php
	include('after.php');
?>