<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_dwpi/content.css">
	<script type="text/javascript" src="extract_dwpi/content.js"></script>
<?php
	include("extract_dwpi/content.php");
?>
<?php 
	include('after.php');
?>