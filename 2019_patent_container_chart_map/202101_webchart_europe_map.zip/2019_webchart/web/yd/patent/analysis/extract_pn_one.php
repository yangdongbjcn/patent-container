<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_pn_one/content.css">
	<script type="text/javascript" src="extract_pn_one/content.js"></script>
<?php
	include("extract_pn_one/content.php");
?>
<?php 
	include('after.php');
?>