<?php 
	include('before.php');
?>
	<link rel="stylesheet" href="extract_year/content.css">
	<script type="text/javascript" src="extract_year/content.js"></script>
<?php
	include("extract_year/content.php");
?>
<?php 
	include('after.php');
?>